/*
    Copyright (c) 2017 Contributors as noted in the AUTHORS file

    This file is part of libzmq, the ZeroMQ core engine in C++.

    libzmq is free software; you can redistribute it and/or modify it under
    the terms of the GNU Lesser General Public License (LGPL) as published
    by the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    As a special exception, the Contributors give you permission to link
    this library with independent modules to produce an executable,
    regardless of the license terms of these independent modules, and to
    copy and distribute the resulting executable under terms of your choice,
    provided that you also meet, for each linked independent module, the
    terms and conditions of the license of that module. An independent
    module is a module which is not derived from or based on this library.
    If you modify this library, you must extend this exception to your
    version of the library.

    libzmq is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public
    License for more details.

    You should have received a copy of the GNU Lesser General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "testutil.hpp"
#include "testutil_unity.hpp"

#include <unity.h>

void setUp ()
{
    setup_test_context ();
}

void tearDown ()
{
    teardown_test_context ();
}

void test_reconnect_ivl_against_pair_socket (const char *my_endpoint, void *sb)
{
    void *sc = test_context_socket (ZMQ_PAIR);
    int interval = -1;
    TEST_ASSERT_SUCCESS_ERRNO (
      zmq_setsockopt (sc, ZMQ_RECONNECT_IVL, &interval, sizeof (int)));
    TEST_ASSERT_SUCCESS_ERRNO (zmq_connect (sc, my_endpoint));

    bounce (sb, sc);

    TEST_ASSERT_SUCCESS_ERRNO (zmq_unbind (sb, my_endpoint));

    expect_bounce_fail (sb, sc);

    TEST_ASSERT_SUCCESS_ERRNO (zmq_bind (sb, my_endpoint));

    expect_bounce_fail (sb, sc);

    TEST_ASSERT_SUCCESS_ERRNO (zmq_connect (sc, my_endpoint));

    bounce (sb, sc);

    test_context_socket_close (sc);
}

#ifndef ZMQ_HAVE_WINDOWS
void test_reconnect_ivl_ipc (void)
{
    const char *ipc_endpoint = "ipc:///tmp/test_reconnect_ivl";
    void *sb = test_context_socket (ZMQ_PAIR);
    TEST_ASSERT_SUCCESS_ERRNO (zmq_bind (sb, ipc_endpoint));

    test_reconnect_ivl_against_pair_socket (ipc_endpoint, sb);
    test_context_socket_close (sb);
}
#endif

void test_reconnect_ivl_tcp (const char *address)
{
    size_t len = MAX_SOCKET_STRING;
    char my_endpoint[MAX_SOCKET_STRING];

    void *sb = test_context_socket (ZMQ_PAIR);
    TEST_ASSERT_SUCCESS_ERRNO (zmq_bind (sb, address));
    TEST_ASSERT_SUCCESS_ERRNO (
      zmq_getsockopt (sb, ZMQ_LAST_ENDPOINT, my_endpoint, &len));

    test_reconnect_ivl_against_pair_socket (my_endpoint, sb);
    test_context_socket_close (sb);
}

void test_reconnect_ivl_tcp_ipv4 ()
{
    test_reconnect_ivl_tcp ("tcp://127.0.0.1:*");
}

void test_reconnect_ivl_tcp_ipv6 ()
{
    if (is_ipv6_available ()) {
        zmq_ctx_set (get_test_context (), ZMQ_IPV6, 1);
        test_reconnect_ivl_tcp ("tcp://[::1]:*");
    }
}

int main (void)
{
    setup_test_environment ();

    UNITY_BEGIN ();
#ifndef ZMQ_HAVE_WINDOWS
    RUN_TEST (test_reconnect_ivl_ipc);
#endif
    RUN_TEST (test_reconnect_ivl_tcp_ipv4);
    RUN_TEST (test_reconnect_ivl_tcp_ipv6);

    return UNITY_END ();
}
